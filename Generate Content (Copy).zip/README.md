
  # Generate Content (Copy)

  This is a code bundle for Generate Content (Copy). The original project is available at https://www.figma.com/design/iYdVphiY4FHxWAOlSGyxcp/Generate-Content--Copy-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  